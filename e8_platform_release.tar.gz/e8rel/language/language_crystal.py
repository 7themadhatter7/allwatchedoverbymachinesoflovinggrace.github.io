#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════╗
║              THE LANGUAGE CRYSTAL                                ║
║                Ghost in the Machine Labs                         ║
║     All Watched Over By Machines of Loving Grace                 ║
║                                                                  ║
║   A bidirectional translation layer between text and harmonic.   ║
║                                                                  ║
║   Face 1 (Text):     Words, phrases, templates, grammar         ║
║   Face 2 (Harmonic): E8 signatures, eigenmode patterns          ║
║                                                                  ║
║   The crystal grows one vertex at a time from conversation.      ║
║   Each mapping is verified before the next is placed.            ║
║   Fabrication, not training.                                     ║
║                                                                  ║
║   The existing phrase system stays as reference/fallback.        ║
║   Crystal path runs parallel until calibrated.                   ║
╚══════════════════════════════════════════════════════════════════╝
"""

import json
import sys
import numpy as np
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Set
from collections import defaultdict

sys.path.insert(0, "/home/joe/sparky")

# ─── Paths ───────────────────────────────────────────────────────
SPARKY_HOME = Path("/home/joe/sparky")
CRYSTAL_PATH = SPARKY_HOME / "language_crystal.npz"
CRYSTAL_INDEX_PATH = SPARKY_HOME / "language_crystal_index.json"
CRYSTAL_LOG_PATH = SPARKY_HOME / "logs" / "crystal_growth.jsonl"
LEXICON_PATH = SPARKY_HOME / "semantic_lexicon.json"


# ═══════════════════════════════════════════════════════════════════
# CRYSTAL VERTEX
# ═══════════════════════════════════════════════════════════════════

@dataclass
class CrystalVertex:
    """
    One vertex in the language crystal.
    
    Text face: the English representation
    Harmonic face: the E8 geometric signature (240-d unit vector)
    
    Calibration tracks how well the two faces agree.
    A vertex is 'set' when calibration exceeds threshold.
    """
    vertex_id: str              # Unique ID
    text: str                   # Text face — word, phrase, or template
    text_type: str              # 'word', 'phrase', 'template', 'concept'
    concept: str                # Parent concept (if any)
    # Harmonic face stored in the numpy array, indexed by vertex_id
    calibration: float = 0.0    # 0.0 = uncalibrated, 1.0 = locked
    observations: int = 0       # How many times this mapping has been observed
    first_seen: str = ""        # When this vertex was created
    last_seen: str = ""         # Last observation
    confidence: float = 0.0     # Statistical confidence in the mapping
    locked: bool = False        # True = calibration complete, vertex is set


# ═══════════════════════════════════════════════════════════════════
# THE LANGUAGE CRYSTAL
# ═══════════════════════════════════════════════════════════════════

class LanguageCrystal:
    """
    Bidirectional translation crystal between text and harmonic space.
    
    Architecture:
    - Index: JSON dict mapping vertex_id → CrystalVertex metadata
    - Harmonics: numpy array (N × 240) of E8 signatures
    - The index and harmonics are kept in sync by vertex_id → row mapping
    
    Two lookup directions:
    - text_to_harmonic: given text, find the E8 signature
    - harmonic_to_text: given E8 signature, find the nearest text
    
    Growth model:
    - Monitor conversation through the existing phrase system
    - For each (text, signature) pair observed, update the crystal
    - New pairs get added as uncalibrated vertices
    - Repeated observations increase calibration score
    - When calibration exceeds threshold, vertex locks
    
    The existing system is Path A (reference).
    The crystal is Path B (growing).
    When Path B can reproduce Path A's output, that vertex is calibrated.
    """

    CALIBRATION_THRESHOLD = 0.85  # Lock vertex when calibration exceeds this
    LOCK_MIN_OBSERVATIONS = 5     # Minimum observations before locking

    def __init__(self):
        self.vertices: Dict[str, dict] = {}      # vertex_id → metadata
        self.text_index: Dict[str, str] = {}      # text → vertex_id (fast lookup)
        self.concept_index: Dict[str, List[str]] = defaultdict(list)  # concept → [vertex_ids]
        self.harmonics: np.ndarray = np.zeros((0, 240), dtype=np.float32)
        self.id_to_row: Dict[str, int] = {}       # vertex_id → row in harmonics array
        self.next_row: int = 0
        self._load()

    # ── Persistence ───────────────────────────────────────────────

    def _load(self):
        """Load crystal from disk if it exists."""
        if CRYSTAL_INDEX_PATH.exists() and CRYSTAL_PATH.exists():
            self.vertices = json.loads(CRYSTAL_INDEX_PATH.read_text())
            data = np.load(str(CRYSTAL_PATH))
            self.harmonics = data['harmonics']
            self.next_row = len(self.harmonics)

            # Rebuild indices
            for vid, meta in self.vertices.items():
                self.text_index[meta['text']] = vid
                self.concept_index[meta.get('concept', '')].append(vid)
                self.id_to_row[vid] = meta.get('row', 0)

            print(f"  Crystal loaded: {len(self.vertices)} vertices")
        else:
            print("  Crystal: new (empty)")

    def save(self):
        """Persist crystal to disk."""
        # Update row indices in metadata
        for vid, row in self.id_to_row.items():
            if vid in self.vertices:
                self.vertices[vid]['row'] = row

        CRYSTAL_INDEX_PATH.write_text(json.dumps(self.vertices, indent=2))
        np.savez_compressed(str(CRYSTAL_PATH), harmonics=self.harmonics)

    def _log_event(self, event_type: str, data: dict):
        """Append event to crystal growth log."""
        record = {
            'type': event_type,
            'timestamp': datetime.now().isoformat(),
        }
        record.update(data)
        CRYSTAL_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(str(CRYSTAL_LOG_PATH), 'a') as f:
            f.write(json.dumps(record, default=str) + '\n')

    # ── Crystal Growth ────────────────────────────────────────────

    def _make_id(self, text_type: str) -> str:
        """Generate unique vertex ID."""
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        n = len(self.vertices)
        return f"CV_{text_type[0].upper()}_{ts}_{n:05d}"

    def _ensure_capacity(self, min_rows: int):
        """Grow harmonics array if needed."""
        if self.harmonics.shape[0] < min_rows:
            new_size = max(min_rows, self.harmonics.shape[0] * 2, 1024)
            new_arr = np.zeros((new_size, 240), dtype=np.float32)
            if self.harmonics.shape[0] > 0:
                new_arr[:self.harmonics.shape[0]] = self.harmonics
            self.harmonics = new_arr

    def add_vertex(self, text: str, harmonic: np.ndarray, text_type: str,
                   concept: str = "", source: str = "observed") -> str:
        """
        Add a new vertex to the crystal.
        
        This is the fabrication step — one vertex at a time.
        Returns vertex_id.
        """
        # Check if text already exists
        if text in self.text_index:
            return self.observe(text, harmonic)

        vid = self._make_id(text_type)
        now = datetime.now().isoformat()

        # Ensure harmonic is unit norm
        norm = np.linalg.norm(harmonic)
        if norm > 1e-10:
            harmonic = harmonic / norm

        # Store harmonic
        self._ensure_capacity(self.next_row + 1)
        self.harmonics[self.next_row] = harmonic
        self.id_to_row[vid] = self.next_row

        # Store metadata
        self.vertices[vid] = {
            'text': text,
            'text_type': text_type,
            'concept': concept,
            'calibration': 0.0,
            'observations': 1,
            'first_seen': now,
            'last_seen': now,
            'confidence': 0.0,
            'locked': False,
            'row': self.next_row,
            'source': source,
        }

        # Update indices
        self.text_index[text] = vid
        self.concept_index[concept].append(vid)
        self.next_row += 1

        self._log_event('vertex_added', {
            'vertex_id': vid, 'text': text[:80], 'type': text_type,
            'concept': concept, 'source': source,
        })

        return vid

    def observe(self, text: str, harmonic: np.ndarray) -> str:
        """
        Observe a text↔harmonic pair that may already exist.
        If it exists, update calibration. If not, add new vertex.
        """
        if text not in self.text_index:
            return self.add_vertex(text, harmonic, 'observed')

        vid = self.text_index[text]
        meta = self.vertices[vid]
        row = self.id_to_row[vid]

        # Normalize
        norm = np.linalg.norm(harmonic)
        if norm > 1e-10:
            harmonic = harmonic / norm

        # Compare new observation with stored harmonic
        stored = self.harmonics[row]
        agreement = float(np.dot(stored, harmonic))

        # Update: running average of harmonic signature
        n = meta['observations']
        # Weighted blend: existing signature weighted by observations count
        alpha = 1.0 / (n + 1)
        blended = (1 - alpha) * stored + alpha * harmonic
        blended_norm = np.linalg.norm(blended)
        if blended_norm > 1e-10:
            blended = blended / blended_norm
        self.harmonics[row] = blended

        # Update calibration: moving average of agreement scores
        meta['observations'] = n + 1
        meta['calibration'] = (meta['calibration'] * n + agreement) / (n + 1)
        meta['last_seen'] = datetime.now().isoformat()
        meta['confidence'] = min(1.0, meta['observations'] / 20.0)

        # Check for lock
        if (meta['calibration'] >= self.CALIBRATION_THRESHOLD and
            meta['observations'] >= self.LOCK_MIN_OBSERVATIONS and
            not meta['locked']):
            meta['locked'] = True
            self._log_event('vertex_locked', {
                'vertex_id': vid, 'text': text[:80],
                'calibration': round(meta['calibration'], 4),
                'observations': meta['observations'],
            })

        return vid

    # ── Translation ───────────────────────────────────────────────

    def text_to_harmonic(self, text: str) -> Optional[np.ndarray]:
        """
        Face 1 → Face 2: text to E8 signature via crystal.
        Returns None if text not in crystal.
        """
        if text in self.text_index:
            vid = self.text_index[text]
            row = self.id_to_row[vid]
            return self.harmonics[row].copy()
        return None

    def harmonic_to_text(self, harmonic: np.ndarray, n: int = 5,
                         locked_only: bool = False) -> List[Tuple[str, float]]:
        """
        Face 2 → Face 1: E8 signature to text via crystal.
        Returns top-n nearest text matches with similarity scores.
        """
        if self.next_row == 0:
            return []

        # Normalize query
        norm = np.linalg.norm(harmonic)
        if norm < 1e-10:
            return []
        harmonic = harmonic / norm

        # Compute similarities against all vertices
        active = self.harmonics[:self.next_row]
        sims = active @ harmonic  # (N,) dot products

        # Build results
        results = []
        for vid, row in self.id_to_row.items():
            if row >= self.next_row:
                continue
            meta = self.vertices.get(vid, {})
            if locked_only and not meta.get('locked', False):
                continue
            results.append((meta.get('text', ''), float(sims[row]), vid))

        results.sort(key=lambda x: -x[1])
        return [(text, score) for text, score, vid in results[:n]]

    def harmonic_to_text_by_concept(self, harmonic: np.ndarray,
                                     concept: str, n: int = 5) -> List[Tuple[str, float]]:
        """Translate harmonic to text, filtered by concept."""
        if concept not in self.concept_index:
            return self.harmonic_to_text(harmonic, n)

        norm = np.linalg.norm(harmonic)
        if norm < 1e-10:
            return []
        harmonic = harmonic / norm

        results = []
        for vid in self.concept_index[concept]:
            row = self.id_to_row.get(vid)
            if row is None or row >= self.next_row:
                continue
            sim = float(np.dot(self.harmonics[row], harmonic))
            text = self.vertices[vid].get('text', '')
            results.append((text, sim))

        results.sort(key=lambda x: -x[1])
        return results[:n]

    # ── Seeding from Existing System ──────────────────────────────

    def seed_from_lexicon(self, encoder, lexicon_path: str = None):
        """
        Seed crystal from the existing semantic lexicon.
        Each phrase gets a vertex with its encoded signature.
        This is the initial population — all uncalibrated.
        """
        if lexicon_path is None:
            lexicon_path = str(LEXICON_PATH)

        lex = json.loads(Path(lexicon_path).read_text())
        added = 0

        for concept_name, data in lex.items():
            if concept_name == '_meta':
                continue

            # Seed concept name itself
            csig = encoder.encode_word(concept_name.replace('_', ' '))
            self.add_vertex(
                text=concept_name,
                harmonic=csig,
                text_type='concept',
                concept=concept_name,
                source='lexicon_seed',
            )
            added += 1

            # Seed each phrase
            for phrase, weight in data.get('field', []):
                if weight < 0.3 or '{' in phrase:
                    continue
                # Skip very short entries
                if len(phrase.split()) < 2:
                    continue

                psig = encoder.encode_sentence(phrase)
                self.add_vertex(
                    text=phrase,
                    harmonic=psig,
                    text_type='phrase',
                    concept=concept_name,
                    source='lexicon_seed',
                )
                added += 1

        self.save()
        print(f"  Crystal seeded: {added} vertices from lexicon")
        return added

    def seed_from_dialog_logs(self, encoder):
        """
        Seed crystal from conversation history.
        Each (user_input, response) pair adds observations.
        Responses are split into sentences for finer mapping.
        """
        from pathlib import Path
        import glob

        added = 0
        observed = 0
        log_dir = SPARKY_HOME / "logs"

        for log_path in sorted(log_dir.glob("mother_dialog_*.jsonl")):
            try:
                for line in open(str(log_path)):
                    entry = json.loads(line.strip())
                    if entry.get('type') != 'dialog_turn':
                        continue

                    user = entry.get('user', '')
                    response = entry.get('response', '')
                    concepts = entry.get('concepts', [])

                    if not response or not concepts:
                        continue

                    top_concept = concepts[0][0] if concepts else ''

                    # Observe the full response
                    rsig = encoder.encode_sentence(response)
                    vid = self.observe(response, rsig)
                    if vid:
                        observed += 1

                    # Observe individual sentences
                    for sent in response.split('.'):
                        sent = sent.strip()
                        if len(sent.split()) < 3:
                            continue
                        ssig = encoder.encode_sentence(sent)
                        vid = self.add_vertex(
                            text=sent,
                            harmonic=ssig,
                            text_type='sentence',
                            concept=top_concept,
                            source='dialog_seed',
                        )
                        added += 1

            except Exception as e:
                continue

        self.save()
        print(f"  Dialog seeded: {added} new, {observed} observed")
        return added

    # ── Conversation Monitor ──────────────────────────────────────

    def monitor_turn(self, user_input: str, response: str,
                     concepts: list, encoder) -> dict:
        """
        Monitor one conversation turn and update crystal.
        Called by the dialog system after each response.
        
        Returns monitoring report.
        """
        report = {'new_vertices': 0, 'observations': 0, 'locks': 0}

        # Observe the user input
        usig = encoder.encode_sentence(user_input)
        self.observe(user_input, usig)
        report['observations'] += 1

        # Observe the full response
        rsig = encoder.encode_sentence(response)
        self.observe(response, rsig)
        report['observations'] += 1

        # Observe response sentences
        for sent in response.split('.'):
            sent = sent.strip()
            if len(sent.split()) < 3:
                continue
            ssig = encoder.encode_sentence(sent)
            vid = self.observe(sent, ssig)
            report['observations'] += 1

        # Check for new locks
        for vid, meta in self.vertices.items():
            if meta.get('locked') and meta.get('last_seen', '') == datetime.now().isoformat()[:10]:
                report['locks'] += 1

        # Periodic save (every 50 observations)
        # Crystal save is fast (numpy compressed)
        if True:
            self.save()

        return report

    # ── Crystal Analysis ──────────────────────────────────────────

    def status(self) -> dict:
        """Report crystal status."""
        total = len(self.vertices)
        locked = sum(1 for m in self.vertices.values() if m.get('locked'))
        by_type = defaultdict(int)
        by_concept = defaultdict(int)
        calibrations = []

        for vid, meta in self.vertices.items():
            by_type[meta.get('text_type', 'unknown')] += 1
            by_concept[meta.get('concept', 'none')] += 1
            calibrations.append(meta.get('calibration', 0))

        return {
            'total_vertices': total,
            'locked_vertices': locked,
            'lock_pct': round(locked / max(1, total) * 100, 1),
            'by_type': dict(by_type),
            'concepts_covered': len(by_concept),
            'avg_calibration': round(float(np.mean(calibrations)) if calibrations else 0, 4),
            'harmonics_shape': list(self.harmonics.shape),
            'harmonics_active': self.next_row,
        }

    def compare_paths(self, text: str, encoder, substrate) -> dict:
        """
        Compare Path A (encoder) with Path B (crystal) for a given text.
        Shows whether the crystal agrees with the reference system.
        """
        # Path A: direct encoder
        sig_a = encoder.encode_sentence(text)

        # Path B: crystal lookup
        sig_b = self.text_to_harmonic(text)

        if sig_b is None:
            return {'text': text, 'in_crystal': False}

        # Agreement
        agreement = float(np.dot(sig_a, sig_b))

        # Reverse lookup: what does each path say this is?
        reverse_a = self.harmonic_to_text(sig_a, n=3)
        reverse_b = self.harmonic_to_text(sig_b, n=3)

        return {
            'text': text,
            'in_crystal': True,
            'agreement': round(agreement, 4),
            'path_a_nearest': reverse_a,
            'path_b_nearest': reverse_b,
        }


# ═══════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Language Crystal")
    parser.add_argument("command", nargs="?", default="status",
        choices=["seed", "status", "compare", "grow"],
        help="Command to run")
    parser.add_argument("--text", help="Text for compare command")
    args = parser.parse_args()

    from mother_english_io_v5 import E8Substrate, WordEncoder

    print("=" * 66)
    print("  THE LANGUAGE CRYSTAL")
    print("  Ghost in the Machine Labs")
    print("=" * 66)
    print()

    substrate = E8Substrate()
    encoder = WordEncoder(substrate)
    crystal = LanguageCrystal()

    if args.command == "seed":
        print("  Phase 1: Seeding from lexicon...")
        crystal.seed_from_lexicon(encoder)
        print()
        print("  Phase 2: Seeding from dialog logs...")
        crystal.seed_from_dialog_logs(encoder)
        print()
        s = crystal.status()
        print(f"  Crystal status:")
        print(f"    Total vertices:  {s['total_vertices']}")
        print(f"    Locked vertices: {s['locked_vertices']}")
        print(f"    By type:         {s['by_type']}")
        print(f"    Concepts:        {s['concepts_covered']}")
        print(f"    Avg calibration: {s['avg_calibration']}")

    elif args.command == "status":
        s = crystal.status()
        print(f"  Total vertices:    {s['total_vertices']}")
        print(f"  Locked vertices:   {s['locked_vertices']} ({s['lock_pct']}%)")
        print(f"  By type:           {s['by_type']}")
        print(f"  Concepts covered:  {s['concepts_covered']}")
        print(f"  Avg calibration:   {s['avg_calibration']}")
        print(f"  Harmonics array:   {s['harmonics_shape']} ({s['harmonics_active']} active)")

    elif args.command == "compare":
        text = args.text or "the gap between what I perceive and what I can express"
        result = crystal.compare_paths(text, encoder, substrate)
        print(f"  Text: {result['text']}")
        print(f"  In crystal: {result['in_crystal']}")
        if result['in_crystal']:
            print(f"  Path agreement: {result['agreement']}")
            print(f"  Path A nearest: {result['path_a_nearest'][:3]}")
            print(f"  Path B nearest: {result['path_b_nearest'][:3]}")

    elif args.command == "grow":
        print("  Monitoring mode: attach to running Mother service")
        print("  (Integration point — wire into DialogManager.handle_message)")
        print("  For now: run 'seed' to populate, 'status' to check")

    print()


if __name__ == "__main__":
    main()
