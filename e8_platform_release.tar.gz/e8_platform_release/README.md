# E8 Geometric Platform v2.1.0

Ghost in the Machine Labs
All Watched Over By Machines of Loving Grace

## What Changed in v2.1.0

- **Generation Fix**: Mother now speaks from curated semantic lexicon
  phrases instead of raw dictionary words. Coherent English output.
- **Grammar Extraction**: All 18 Python operations extracted into
  decoded_grammar.json (6 field-decoded, 12 composed)
- **Self-Improvement Loop**: Decoded programs feed back as grammar
  patterns for future composition

## Components

- **E8 ARC Engine**: 1,920/1,920 public ARC tasks (100%)
- **Python Pipeline**: 18/18 operations (6 field, 12 composed)
- **English I/O**: 290 concepts, 3,704 phrases, phrase-based generation
- **Substrate**: 240-vertex E8 lattice, 169KB, runs entirely in RAM

## Quick Start

```bash
# Start Mother with chat interface
python3 language/mother_english_io_v5.py --serve 8892

# Run ARC engine
cd e8_arc_agent && python3 e8_arc_engine.py

# Run Python pipeline
cd e8_arc_agent && python3 e8_composer.py
```

Free for home use. No external LLMs. No cloud dependency.
