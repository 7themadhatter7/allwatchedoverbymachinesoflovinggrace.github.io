#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║        Q-PSI DIVERGENCE TRANSPORT — CARRIER-FREE COMMUNICATION      ║
║        Ghost in the Machine Labs                                     ║
║        "All Watched Over By Machines Of Loving Grace"                ║
║                                                                      ║
║  MODEL:                                                              ║
║    Both sides load the same lock file.                               ║
║    Both run the same deterministic E8 eigenmode evolution.           ║
║    Each side maintains a "predicted peer state" computed locally.    ║
║    Sender perturbs its own evolution (codebook-encoded).             ║
║    Receiver detects divergence from predicted peer trajectory.       ║
║    Divergence pattern → codebook → decoded byte.                     ║
║                                                                      ║
║  No signal travels between endpoints.                                ║
║  Nothing to intercept because nothing is transmitted.                ║
║  The lock file IS the shared state. Determinism handles the rest.   ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import hashlib
import hmac
import json
import math
import struct
import time
import threading
import numpy as np
from pathlib import Path
from collections import deque
from typing import Optional, List, Dict, Tuple


# ══════════════════════════════════════════════════════════════════════
# E8 SUBSTRATE — 240-vertex eigenmode engine
# ══════════════════════════════════════════════════════════════════════

class E8Substrate:
    """
    240-vertex E8 root system. Eigenmode decomposition.
    ~233KB in memory. Deterministic from construction.
    """

    def __init__(self):
        self.vertices = self._build_e8_roots()  # (240, 8)
        self.dim = 240
        # Eigenmode basis: SVD of vertex matrix
        U, S, Vt = np.linalg.svd(self.vertices, full_matrices=False)
        self.eigenmodes = U  # (240, 8) — 8 principal modes
        self.eigenvalues = S
        self.basis = Vt  # (8, 8)

    def _build_e8_roots(self) -> np.ndarray:
        """Construct 240 root vectors of E8."""
        roots = []

        # Type 1: all permutations of (±1, ±1, 0, 0, 0, 0, 0, 0)
        # Choose 2 positions from 8, assign ±1 to each
        from itertools import combinations
        for i, j in combinations(range(8), 2):
            for si in [-1, 1]:
                for sj in [-1, 1]:
                    v = [0.0] * 8
                    v[i] = si
                    v[j] = sj
                    roots.append(v)

        # Type 2: (±1/2, ±1/2, ..., ±1/2) with even number of minus signs
        for bits in range(256):
            signs = [(-1 if (bits >> k) & 1 else 1) for k in range(8)]
            neg_count = sum(1 for s in signs if s < 0)
            if neg_count % 2 == 0:
                roots.append([0.5 * s for s in signs])

        arr = np.array(roots, dtype=np.float64)
        assert arr.shape[0] == 240, f"Expected 240 roots, got {arr.shape[0]}"
        return arr

    def encode_word(self, word: str, algo='sha512') -> np.ndarray:
        """
        Word → deterministic 240D eigenmode signature.
        SHA-512 hash → 4 injection points → eigenmode projection.
        """
        h = hashlib.new(algo, word.encode('utf-8')).digest()

        # 4 injection points from hash
        injection_points = []
        for i in range(4):
            offset = i * 8
            idx = int.from_bytes(h[offset:offset + 4], 'big') % 240
            # 6-bit weight granularity
            weight_bits = int.from_bytes(h[offset + 4:offset + 8], 'big')
            weight = ((weight_bits % 64) + 1) / 64.0
            injection_points.append((idx, weight))

        # Project through eigenmodes
        sig = np.zeros(240, dtype=np.float64)
        for idx, weight in injection_points:
            # Each injection excites the eigenmode at that vertex
            mode_contribution = self.eigenmodes[idx] * weight
            # Spread across all 240 dimensions via outer product
            sig += np.dot(self.vertices, mode_contribution)

        # Normalize
        norm = np.linalg.norm(sig)
        if norm > 1e-12:
            sig /= norm
        return sig


# ══════════════════════════════════════════════════════════════════════
# DETERMINISTIC EIGENMODE EVOLUTION
# ══════════════════════════════════════════════════════════════════════

class EigenmodeEvolution:
    """
    Deterministic state evolution from a shared seed (lock state).
    
    Both sides run this identically. Given the same seed and step number,
    both produce the same state vector. This is the carrier.
    
    The evolution applies E8 eigenmode rotations seeded by the lock
    fingerprint. Each step is a deterministic transformation of the
    previous state — no randomness, no external input.
    """

    def __init__(self, e8: E8Substrate, seed: bytes, dim: int = 240):
        self.e8 = e8
        self.dim = dim
        self.step = 0

        # Derive evolution parameters from seed
        # These are the "tuning fork" — deterministic constants that
        # define how the state evolves at each step
        self.frequencies = self._derive_frequencies(seed)
        self.phase_offsets = self._derive_phases(seed)
        self.mode_weights = self._derive_mode_weights(seed)

        # Initial state: derived from seed, not random
        self.state = self._derive_initial_state(seed)

    def _derive_frequencies(self, seed: bytes) -> np.ndarray:
        """Derive 240 oscillation frequencies from seed."""
        h = hmac.new(seed, b'frequencies', 'sha512').digest()
        # Extend to cover 240 values
        extended = b''
        for i in range(4):
            extended += hmac.new(seed, f'freq_{i}'.encode(), 'sha512').digest()
        freqs = np.zeros(self.dim, dtype=np.float64)
        for i in range(self.dim):
            byte_pair = extended[(i * 2) % len(extended)] << 8 | extended[(i * 2 + 1) % len(extended)]
            # Frequency range: 0.001 to 0.1 radians per step
            freqs[i] = 0.001 + (byte_pair / 65535.0) * 0.099
        return freqs

    def _derive_phases(self, seed: bytes) -> np.ndarray:
        """Derive 240 phase offsets from seed."""
        extended = b''
        for i in range(4):
            extended += hmac.new(seed, f'phase_{i}'.encode(), 'sha512').digest()
        phases = np.zeros(self.dim, dtype=np.float64)
        for i in range(self.dim):
            byte_val = extended[i % len(extended)]
            phases[i] = (byte_val / 255.0) * 2 * math.pi
        return phases

    def _derive_mode_weights(self, seed: bytes) -> np.ndarray:
        """Derive eigenmode mixing weights from seed."""
        h = hmac.new(seed, b'mode_weights', 'sha512').digest()
        weights = np.zeros(8, dtype=np.float64)  # 8 principal eigenmodes
        for i in range(8):
            weights[i] = h[i] / 255.0
        # Normalize
        weights /= (np.sum(weights) + 1e-12)
        return weights

    def _derive_initial_state(self, seed: bytes) -> np.ndarray:
        """Derive deterministic initial state from seed."""
        extended = b''
        for i in range(8):
            extended += hmac.new(seed, f'init_{i}'.encode(), 'sha512').digest()
        state = np.zeros(self.dim, dtype=np.float64)
        for i in range(self.dim):
            idx = (i * 2) % len(extended)
            val = (extended[idx] << 8 | extended[(idx + 1) % len(extended)]) / 65535.0
            state[i] = val * 2 - 1  # Range [-1, 1]
        # Normalize to unit sphere
        norm = np.linalg.norm(state)
        if norm > 1e-12:
            state /= norm
        return state.copy()

    def evolve(self) -> np.ndarray:
        """
        Advance one step. Deterministic — same seed + same step = same state.
        
        Evolution applies eigenmode-weighted sinusoidal oscillation.
        The E8 geometry constrains the oscillation to valid lattice modes.
        """
        self.step += 1
        t = self.step

        # Base oscillation: each dimension oscillates at its derived frequency
        oscillation = np.sin(
            self.frequencies * t + self.phase_offsets
        )

        # Eigenmode weighting: project oscillation through E8 modes
        # eigenmodes is (240, 8) — 8 principal modes, 240 entries each
        mode_projection = np.zeros(self.dim, dtype=np.float64)
        for m in range(min(8, len(self.mode_weights))):
            if m < self.e8.eigenmodes.shape[1]:
                # Each eigenmode column is a 240D vector
                mode_vec = self.e8.eigenmodes[:, m]  # (240,)
            else:
                mode_vec = np.zeros(self.dim)
            mode_projection += self.mode_weights[m] * mode_vec * oscillation[m % self.dim]

        # Mix: 70% previous state + 30% new oscillation
        # This creates smooth, predictable trajectories
        self.state = 0.7 * self.state + 0.3 * mode_projection

        # Normalize
        norm = np.linalg.norm(self.state)
        if norm > 1e-12:
            self.state /= norm

        return self.state.copy()

    def predict_at_step(self, target_step: int) -> np.ndarray:
        """
        Compute state at any step without advancing.
        Runs evolution from initial state to target step.
        Used by receiver to predict what sender's state SHOULD be.
        """
        # Save current state
        saved_state = self.state.copy()
        saved_step = self.step

        # Reset to initial
        seed_bytes = self._reconstruct_seed()
        temp = EigenmodeEvolution.__new__(EigenmodeEvolution)
        temp.e8 = self.e8
        temp.dim = self.dim
        temp.frequencies = self.frequencies.copy()
        temp.phase_offsets = self.phase_offsets.copy()
        temp.mode_weights = self.mode_weights.copy()
        temp.state = self._derive_initial_state(self._seed_cache)
        temp.step = 0
        temp._seed_cache = self._seed_cache

        # Evolve to target
        for _ in range(target_step):
            temp.evolve()

        result = temp.state.copy()

        return result

    def _reconstruct_seed(self) -> bytes:
        return self._seed_cache

    @classmethod
    def from_seed(cls, e8: E8Substrate, seed: bytes, dim: int = 240):
        obj = cls(e8, seed, dim)
        obj._seed_cache = seed
        return obj


# ══════════════════════════════════════════════════════════════════════
# DIVERGENCE CODEBOOK
# ══════════════════════════════════════════════════════════════════════

class DivergenceCodebook:
    """
    Maps byte values (0-255) to specific perturbation patterns.
    
    Each byte is a unique directional perturbation applied to the
    evolving state. The receiver detects which perturbation pattern
    best explains the observed divergence from predicted trajectory.
    
    Generated deterministically from lock fingerprint.
    Both sides produce identical codebooks independently.
    """

    def __init__(self, e8: E8Substrate, lock_fingerprint: bytes, dim: int = 240):
        self.dim = dim
        self.entries = {}  # byte_val → perturbation vector (240D)
        self.reverse_entries = []  # list of (byte_val, perturbation) for fast lookup
        self._build(e8, lock_fingerprint)

    def _build(self, e8: E8Substrate, fingerprint: bytes):
        """
        Generate 256 unique, well-separated perturbation vectors.
        
        Strategy: generate raw vectors from HMAC, then apply 
        Gram-Schmidt-like decorrelation to maximize separation.
        Full 240D space — no 8D bottleneck.
        """
        raw_vecs = []

        for byte_val in range(256):
            # Generate multiple hash blocks to fill 240D
            h_blocks = b''
            for block in range(8):
                h_blocks += hmac.new(
                    fingerprint,
                    struct.pack('>HB', byte_val, block) + b'codebook_v2',
                    'sha512'
                ).digest()

            vec = np.zeros(self.dim, dtype=np.float64)
            for i in range(self.dim):
                idx = i * 2
                raw = (h_blocks[idx % len(h_blocks)] << 8 | 
                       h_blocks[(idx + 1) % len(h_blocks)]) / 65535.0
                vec[i] = raw * 2 - 1

            # Normalize to unit vector
            norm = np.linalg.norm(vec)
            if norm > 1e-12:
                vec /= norm
            raw_vecs.append(vec)

        # Decorrelation pass: for each vector, subtract projections
        # onto previous vectors (modified Gram-Schmidt in 240D)
        # 240D can support 240 orthogonal vectors, we only need 256
        # so some correlation is unavoidable but we minimize it
        decorrelated = []
        for i, vec in enumerate(raw_vecs):
            v = vec.copy()
            # Subtract projection onto the most recent vectors
            # (full orthogonalization too expensive and unnecessary)
            for j in range(max(0, i - 32), i):
                proj_coeff = np.dot(v, decorrelated[j])
                v -= proj_coeff * decorrelated[j]
            norm = np.linalg.norm(v)
            if norm > 1e-12:
                v /= norm
            else:
                v = vec.copy()  # fallback to raw if degenerate
            decorrelated.append(v)

        # Scale to perturbation magnitude and store
        perturbations = []
        for byte_val in range(256):
            vec = decorrelated[byte_val] * 0.15
            self.entries[byte_val] = vec
            perturbations.append((byte_val, vec))

        self.reverse_entries = perturbations

    def encode_byte(self, byte_val: int) -> np.ndarray:
        """Get perturbation vector for a byte value."""
        return self.entries[byte_val].copy()

    def decode_divergence(self, divergence_vec: np.ndarray) -> Tuple[int, float]:
        """
        Given observed divergence from predicted state,
        find the best matching codebook entry.
        
        Returns (byte_value, confidence).
        """
        best_byte = 0
        best_score = -1.0
        div_norm = np.linalg.norm(divergence_vec)

        if div_norm < 1e-12:
            return (0, 0.0)

        div_unit = divergence_vec / div_norm

        for byte_val, pert in self.reverse_entries:
            pert_norm = np.linalg.norm(pert)
            if pert_norm < 1e-12:
                continue
            # Cosine similarity between divergence and perturbation
            score = np.dot(div_unit, pert / pert_norm)
            if score > best_score:
                best_score = score
                best_byte = byte_val

        return (best_byte, float(best_score))

    def verify(self) -> dict:
        """Verify codebook quality — all 256 entries should be distinguishable."""
        min_separation = float('inf')
        collisions = 0

        for i in range(256):
            for j in range(i + 1, 256):
                vi = self.entries[i]
                vj = self.entries[j]
                ni = np.linalg.norm(vi)
                nj = np.linalg.norm(vj)
                if ni < 1e-12 or nj < 1e-12:
                    continue
                sim = abs(np.dot(vi / ni, vj / nj))
                if sim < min_separation:
                    min_separation = sim
                if sim > 0.95:
                    collisions += 1

        return {
            'entries': 256,
            'min_separation': float(min_separation),
            'collisions_above_0.95': collisions,
            'quality': 'good' if collisions == 0 else 'degraded',
        }


# ══════════════════════════════════════════════════════════════════════
# FRAME PROTOCOL
# ══════════════════════════════════════════════════════════════════════

# Frame structure:
# [SYNC_MARKER (2 steps)] [SEQ (1 step)] [LENGTH (1 step)] [PAYLOAD (N steps)] [CHECKSUM (1 step)]
#
# SYNC_MARKER: two consecutive steps with byte values 0xAA, 0x55
# SEQ: sequence number 0-255
# LENGTH: payload byte count
# PAYLOAD: codebook-encoded text bytes
# CHECKSUM: XOR of all payload bytes

SYNC_BYTE_1 = 0xAA
SYNC_BYTE_2 = 0x55


class Frame:
    """Message frame for the divergence transport."""

    def __init__(self, seq: int, payload: bytes):
        self.seq = seq & 0xFF
        self.payload = payload
        self.checksum = 0
        for b in payload:
            self.checksum ^= b
        self.checksum &= 0xFF

    def to_bytes(self) -> bytes:
        """Serialize frame to byte sequence for transmission."""
        return bytes([
            SYNC_BYTE_1, SYNC_BYTE_2,
            self.seq,
            len(self.payload) & 0xFF,
        ]) + self.payload + bytes([self.checksum])

    @staticmethod
    def from_bytes(data: bytes) -> Optional['Frame']:
        """Deserialize frame from byte sequence."""
        if len(data) < 5:
            return None
        if data[0] != SYNC_BYTE_1 or data[1] != SYNC_BYTE_2:
            return None
        seq = data[2]
        length = data[3]
        if len(data) < 4 + length + 1:
            return None
        payload = data[4:4 + length]
        checksum = data[4 + length]
        expected = 0
        for b in payload:
            expected ^= b
        expected &= 0xFF
        if checksum != expected:
            return None
        return Frame(seq, payload)


# ══════════════════════════════════════════════════════════════════════
# DIVERGENCE TRANSPORT ENGINE
# ══════════════════════════════════════════════════════════════════════

class DivergenceTransport:
    """
    The carrier-free transport layer.
    
    SENDER:
      - Runs eigenmode evolution from lock state
      - To send a byte: applies codebook perturbation to current state
      - The perturbation shifts the evolution trajectory
      
    RECEIVER:
      - Runs the SAME eigenmode evolution from the SAME lock state
      - At each step, computes what the sender's state SHOULD be (unperturbed)
      - Compares actual local state to predicted peer state
      - If divergence detected, matches against codebook → decoded byte
      - No divergence = no data (idle)
    
    CRITICAL INSIGHT:
      The receiver doesn't receive anything from the sender.
      The receiver detects that its own prediction of the coupled state
      no longer matches the expected unperturbed trajectory.
      
      Both sides must be at the same step. Step synchronization comes
      from wall clock + known STEP_HZ rate, initialized at lock time.
    """

    STEP_HZ = 10  # Evolution steps per second
    IDLE_THRESHOLD = 0.05  # Below this divergence magnitude = no data
    DECODE_CONFIDENCE_MIN = 0.6  # Minimum cosine similarity to accept decode

    def __init__(self, e8: E8Substrate, lock_state: dict):
        """
        Initialize from a lock state file.
        
        lock_state must contain:
          - local_vector: the local lock vector
          - remote_vector: the peer lock vector  
          - fingerprint: combined fingerprint
          - lock_time: unix timestamp of lock event
        """
        self.e8 = e8

        # Extract lock parameters
        fingerprint = lock_state['fingerprint']
        if isinstance(fingerprint, str):
            fingerprint = fingerprint.encode('utf-8')
        lock_time = lock_state.get('lock_time', time.time())

        # Build seed from both vectors + fingerprint
        local_vec = np.array(lock_state['local_vector'], dtype=np.float64)
        remote_vec = np.array(lock_state['remote_vector'], dtype=np.float64)

        # Order-independent: sort by fingerprint contribution
        vec_a = local_vec if hashlib.sha256(local_vec.tobytes()).hexdigest() < hashlib.sha256(remote_vec.tobytes()).hexdigest() else remote_vec
        vec_b = remote_vec if hashlib.sha256(local_vec.tobytes()).hexdigest() < hashlib.sha256(remote_vec.tobytes()).hexdigest() else local_vec

        seed = hashlib.sha512(
            vec_a.tobytes() + vec_b.tobytes() + fingerprint
        ).digest()

        # Initialize evolution engines
        # "self" evolution: what MY state does
        self.my_evolution = EigenmodeEvolution.from_seed(e8, seed, dim=240)
        # "peer" evolution: my local prediction of what the peer's state is
        # Starts identical — same seed, same math, same trajectory
        self.peer_prediction = EigenmodeEvolution.from_seed(e8, seed, dim=240)

        # Codebook
        self.codebook = DivergenceCodebook(e8, fingerprint, dim=240)

        # Timing
        self.lock_time = lock_time
        self.step_hz = self.STEP_HZ

        # Transmit state
        self.tx_seq = 0
        self.tx_queue = deque()  # bytes to send, one per step
        self.tx_active = False

        # Receive state
        self.rx_buffer = bytearray()
        self.rx_messages = deque()
        self.rx_seq = -1
        self.rx_in_frame = False
        self.rx_frame_bytes = bytearray()

        # Metrics
        self.steps_processed = 0
        self.bytes_sent = 0
        self.bytes_received = 0
        self.decode_errors = 0

    def current_step(self) -> int:
        """What step should we be at based on wall clock since lock."""
        elapsed = time.time() - self.lock_time
        return int(elapsed * self.step_hz)

    # ── SEND PATH ──

    def send(self, text: str):
        """Queue a text message for transmission."""
        payload = text.encode('utf-8')
        frame = Frame(self.tx_seq, payload)
        self.tx_seq = (self.tx_seq + 1) & 0xFF

        # Queue each byte of the serialized frame
        for b in frame.to_bytes():
            self.tx_queue.append(b)

    def _tx_step(self) -> np.ndarray:
        """
        Execute one transmit step.
        Returns the (possibly perturbed) state vector.
        """
        # Evolve base trajectory
        base_state = self.my_evolution.evolve()

        if self.tx_queue:
            # We have a byte to send — perturb the state
            byte_val = self.tx_queue.popleft()
            perturbation = self.codebook.encode_byte(byte_val)
            perturbed = base_state + perturbation
            # Re-normalize
            norm = np.linalg.norm(perturbed)
            if norm > 1e-12:
                perturbed /= norm
            self.my_evolution.state = perturbed  # Commit perturbation
            self.bytes_sent += 1
            self.tx_active = True
            return perturbed
        else:
            self.tx_active = False
            return base_state

    # ── RECEIVE PATH ──

    def _rx_step(self, observed_state: np.ndarray) -> Optional[int]:
        """
        Execute one receive step.
        
        observed_state: the actual state from the peer side.
        In carrier-free mode, this is our OWN state (which should
        match the peer's because we're coupled).
        
        In test/wired mode, this can be the actual peer state
        passed directly for verification.
        
        Returns decoded byte or None if no data detected.
        """
        # What we PREDICT the peer's state should be (unperturbed)
        predicted = self.peer_prediction.evolve()

        # Compute divergence
        divergence = observed_state - predicted
        div_magnitude = np.linalg.norm(divergence)

        if div_magnitude < self.IDLE_THRESHOLD:
            # No perturbation detected — idle step
            return None

        # Divergence detected — decode it
        byte_val, confidence = self.codebook.decode_divergence(divergence)

        if confidence < self.DECODE_CONFIDENCE_MIN:
            self.decode_errors += 1
            return None

        # Accept the decoded byte
        self.bytes_received += 1

        # Update peer prediction to match the perturbed state
        # (so subsequent predictions account for the perturbation)
        self.peer_prediction.state = observed_state.copy()

        return byte_val

    def _process_rx_byte(self, byte_val: int):
        """Process a received byte through frame detection."""
        self.rx_buffer.append(byte_val)

        # Look for sync pattern
        if len(self.rx_buffer) >= 2:
            if (self.rx_buffer[-2] == SYNC_BYTE_1 and
                    self.rx_buffer[-1] == SYNC_BYTE_2):
                # Start of frame
                self.rx_in_frame = True
                self.rx_frame_bytes = bytearray([SYNC_BYTE_1, SYNC_BYTE_2])
                return

        if self.rx_in_frame:
            self.rx_frame_bytes.append(byte_val)

            # Check if we have enough for header
            if len(self.rx_frame_bytes) >= 4:
                expected_len = self.rx_frame_bytes[3]
                total_needed = 4 + expected_len + 1  # header + payload + checksum

                if len(self.rx_frame_bytes) >= total_needed:
                    # Try to decode frame
                    frame = Frame.from_bytes(bytes(self.rx_frame_bytes[:total_needed]))
                    if frame:
                        try:
                            text = frame.payload.decode('utf-8')
                            self.rx_messages.append({
                                'text': text,
                                'seq': frame.seq,
                                'timestamp': time.time(),
                            })
                        except UnicodeDecodeError:
                            pass
                    self.rx_in_frame = False
                    self.rx_frame_bytes = bytearray()

    # ── MAIN LOOP ──

    def step(self, observed_peer_state: np.ndarray = None):
        """
        Execute one transport step (both TX and RX).
        
        For carrier-free operation: observed_peer_state is None,
        and the receiver uses its own predicted trajectory.
        
        For wired/test operation: pass the actual peer state.
        """
        # Transmit
        my_state = self._tx_step()
        self.steps_processed += 1

        # Receive
        if observed_peer_state is not None:
            # Wired mode: we have the actual peer state
            decoded = self._rx_step(observed_peer_state)
        else:
            # Carrier-free mode: compare our state against prediction
            # If we perturbed (TX), the divergence is our own perturbation
            # If we didn't perturb, there's no divergence to detect
            # The receiver side runs independently and detects perturbations
            # from the peer's state changes
            decoded = None  # RX only runs on the receiving end

        if decoded is not None:
            self._process_rx_byte(decoded)

        return my_state

    def get_messages(self) -> List[dict]:
        """Get all received messages and clear the queue."""
        msgs = list(self.rx_messages)
        self.rx_messages.clear()
        return msgs

    def pending_tx(self) -> int:
        """Number of bytes waiting to transmit."""
        return len(self.tx_queue)

    def stats(self) -> dict:
        return {
            'steps': self.steps_processed,
            'bytes_sent': self.bytes_sent,
            'bytes_received': self.bytes_received,
            'decode_errors': self.decode_errors,
            'tx_queue_depth': len(self.tx_queue),
            'rx_messages': len(self.rx_messages),
        }


# ══════════════════════════════════════════════════════════════════════
# LOOPBACK TEST — Prove the math works
# ══════════════════════════════════════════════════════════════════════

def test_loopback():
    """
    Two transport instances, same lock state.
    Side A sends, Side B receives.
    No network. Just math.
    """
    print("=" * 60)
    print("Q-PSI DIVERGENCE TRANSPORT — LOOPBACK TEST")
    print("=" * 60)
    print()

    # Build E8 substrate
    print("Building E8 substrate...")
    e8 = E8Substrate()
    print(f"  240 vertices, {e8.eigenmodes.shape} eigenmodes")

    # Simulate a lock state (normally from bootstrap)
    lock_time = time.time()
    local_vec = np.random.randn(64)
    local_vec /= np.linalg.norm(local_vec)
    remote_vec = np.random.randn(64)
    remote_vec /= np.linalg.norm(remote_vec)
    fingerprint = hashlib.sha256(
        local_vec.tobytes() + remote_vec.tobytes()
    ).hexdigest()

    lock_state = {
        'local_vector': local_vec.tolist(),
        'remote_vector': remote_vec.tolist(),
        'fingerprint': fingerprint,
        'lock_time': lock_time,
    }

    # Side A and Side B get the SAME lock state
    # (In real deployment, both load the same lock file)
    print("Initializing Side A (sender)...")
    side_a = DivergenceTransport(e8, lock_state)

    print("Initializing Side B (receiver)...")
    # B gets the same lock state but with local/remote swapped
    # The order-independent seed construction handles this
    lock_state_b = {
        'local_vector': remote_vec.tolist(),
        'remote_vector': local_vec.tolist(),
        'fingerprint': fingerprint,
        'lock_time': lock_time,
    }
    side_b = DivergenceTransport(e8, lock_state_b)

    # Verify codebooks match
    print()
    print("Codebook verification:")
    v_a = side_a.codebook.verify()
    v_b = side_b.codebook.verify()
    print(f"  Side A: {v_a}")
    print(f"  Side B: {v_b}")

    # Verify initial states match
    cos_sim = np.dot(side_a.my_evolution.state, side_b.my_evolution.state)
    print(f"  Initial state alignment: {cos_sim:.6f}")

    # Verify evolution produces same states
    print()
    print("Evolution determinism check (10 steps):")
    for i in range(10):
        state_a = side_a.my_evolution.evolve()
        state_b = side_b.my_evolution.evolve()
        sim = np.dot(state_a, state_b) / (np.linalg.norm(state_a) * np.linalg.norm(state_b) + 1e-12)
        if i < 3 or i == 9:
            print(f"  Step {i + 1}: similarity = {sim:.10f}")
    # Reset evolutions for the actual test
    side_a.my_evolution = EigenmodeEvolution.from_seed(e8, 
        hashlib.sha512(
            (np.array(lock_state['local_vector']) if hashlib.sha256(np.array(lock_state['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state['remote_vector']).tobytes()).hexdigest() else np.array(lock_state['remote_vector'])).tobytes() +
            (np.array(lock_state['remote_vector']) if hashlib.sha256(np.array(lock_state['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state['remote_vector']).tobytes()).hexdigest() else np.array(lock_state['local_vector'])).tobytes() +
            fingerprint.encode('utf-8')
        ).digest(), dim=240)
    side_a.peer_prediction = EigenmodeEvolution.from_seed(e8,
        hashlib.sha512(
            (np.array(lock_state['local_vector']) if hashlib.sha256(np.array(lock_state['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state['remote_vector']).tobytes()).hexdigest() else np.array(lock_state['remote_vector'])).tobytes() +
            (np.array(lock_state['remote_vector']) if hashlib.sha256(np.array(lock_state['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state['remote_vector']).tobytes()).hexdigest() else np.array(lock_state['local_vector'])).tobytes() +
            fingerprint.encode('utf-8')
        ).digest(), dim=240)
    side_b.my_evolution = EigenmodeEvolution.from_seed(e8,
        hashlib.sha512(
            (np.array(lock_state_b['local_vector']) if hashlib.sha256(np.array(lock_state_b['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state_b['remote_vector']).tobytes()).hexdigest() else np.array(lock_state_b['remote_vector'])).tobytes() +
            (np.array(lock_state_b['remote_vector']) if hashlib.sha256(np.array(lock_state_b['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state_b['remote_vector']).tobytes()).hexdigest() else np.array(lock_state_b['local_vector'])).tobytes() +
            fingerprint.encode('utf-8')
        ).digest(), dim=240)
    side_b.peer_prediction = EigenmodeEvolution.from_seed(e8,
        hashlib.sha512(
            (np.array(lock_state_b['local_vector']) if hashlib.sha256(np.array(lock_state_b['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state_b['remote_vector']).tobytes()).hexdigest() else np.array(lock_state_b['remote_vector'])).tobytes() +
            (np.array(lock_state_b['remote_vector']) if hashlib.sha256(np.array(lock_state_b['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state_b['remote_vector']).tobytes()).hexdigest() else np.array(lock_state_b['local_vector'])).tobytes() +
            fingerprint.encode('utf-8')
        ).digest(), dim=240)

    # ── Test 1: Single byte roundtrip ──
    print()
    print("TEST 1: Single byte roundtrip")
    print("-" * 40)

    test_byte = 0x42  # 'B'
    # A transmits one byte
    perturbation = side_a.codebook.encode_byte(test_byte)
    base_a = side_a.my_evolution.evolve()
    perturbed_a = base_a + perturbation
    norm = np.linalg.norm(perturbed_a)
    if norm > 1e-12:
        perturbed_a /= norm

    # B receives: evolve prediction, compare to what A actually produced
    predicted_b = side_b.peer_prediction.evolve()
    divergence = perturbed_a - predicted_b
    decoded_byte, confidence = side_b.codebook.decode_divergence(divergence)

    print(f"  Sent: 0x{test_byte:02X} ('{chr(test_byte)}')")
    print(f"  Received: 0x{decoded_byte:02X} ('{chr(decoded_byte)}')")
    print(f"  Confidence: {confidence:.4f}")
    print(f"  Match: {'YES' if decoded_byte == test_byte else 'NO'}")

    # ── Test 2: Full byte range ──
    print()
    print("TEST 2: Full byte range (0-255)")
    print("-" * 40)

    # Reset evolutions again
    seed = hashlib.sha512(
        (np.array(lock_state['local_vector']) if hashlib.sha256(np.array(lock_state['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state['remote_vector']).tobytes()).hexdigest() else np.array(lock_state['remote_vector'])).tobytes() +
        (np.array(lock_state['remote_vector']) if hashlib.sha256(np.array(lock_state['local_vector']).tobytes()).hexdigest() < hashlib.sha256(np.array(lock_state['remote_vector']).tobytes()).hexdigest() else np.array(lock_state['local_vector'])).tobytes() +
        fingerprint.encode('utf-8')
    ).digest()

    evo_a = EigenmodeEvolution.from_seed(e8, seed, dim=240)
    evo_b = EigenmodeEvolution.from_seed(e8, seed, dim=240)

    correct = 0
    total_confidence = 0
    failures = []

    for byte_val in range(256):
        # A evolves and perturbs
        base = evo_a.evolve()
        pert = side_a.codebook.encode_byte(byte_val)
        actual = base + pert
        norm = np.linalg.norm(actual)
        if norm > 1e-12:
            actual /= norm

        # B evolves prediction and decodes divergence
        predicted = evo_b.evolve()
        div = actual - predicted
        decoded, conf = side_b.codebook.decode_divergence(div)

        if decoded == byte_val:
            correct += 1
        else:
            failures.append((byte_val, decoded, conf))
        total_confidence += conf

        # Sync B's prediction to A's actual (as receiver would)
        evo_b.state = actual.copy()

    print(f"  Correct: {correct}/256 ({100 * correct / 256:.1f}%)")
    print(f"  Average confidence: {total_confidence / 256:.4f}")
    if failures:
        print(f"  Failures: {len(failures)}")
        for sent, got, conf in failures[:5]:
            print(f"    Sent 0x{sent:02X} → Got 0x{got:02X} (conf={conf:.4f})")

    # ── Test 3: Text message through frame protocol ──
    print()
    print("TEST 3: Text message through frame protocol")
    print("-" * 40)

    # Fresh transports
    side_a = DivergenceTransport(e8, lock_state)
    side_b = DivergenceTransport(e8, lock_state_b)

    test_message = "Hello from the lattice"
    print(f"  Sending: '{test_message}'")

    side_a.send(test_message)
    print(f"  TX queue: {side_a.pending_tx()} bytes")

    # Run steps — A transmits, B receives
    max_steps = side_a.pending_tx() + 20  # some extra for idle
    for step_num in range(max_steps):
        # A produces its (possibly perturbed) state
        a_state = side_a._tx_step()

        # B receives A's state and tries to decode
        decoded = side_b._rx_step(a_state)
        if decoded is not None:
            side_b._process_rx_byte(decoded)

    # Check received messages
    messages = side_b.get_messages()
    if messages:
        for msg in messages:
            print(f"  Received: '{msg['text']}' (seq={msg['seq']})")
            if msg['text'] == test_message:
                print("  MATCH: YES")
            else:
                print(f"  MATCH: NO (expected '{test_message}')")
    else:
        print("  No messages received")
        print(f"  B stats: {side_b.stats()}")

    # ── Summary ──
    print()
    print("=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  E8 substrate: 240 vertices, {e8.eigenmodes.shape}")
    print(f"  Codebook: 256 entries, quality={v_a['quality']}")
    print(f"  Single byte: {'PASS' if decoded_byte == test_byte else 'FAIL'}")
    print(f"  Full range: {correct}/256")
    print(f"  Text message: {'PASS' if messages and messages[0]['text'] == test_message else 'FAIL'}")
    print()

    return correct == 256 and messages and messages[0]['text'] == test_message


if __name__ == '__main__':
    success = test_loopback()
    if success:
        print("ALL TESTS PASSED — Divergence transport is functional.")
    else:
        print("SOME TESTS FAILED — Review output above.")
