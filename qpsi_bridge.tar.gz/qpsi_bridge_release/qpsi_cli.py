#!/usr/bin/env python3
"""
Q-PSI SEND/RECEIVE CLI
Send:    python3 qpsi_cli.py send "your message here"
Receive: python3 qpsi_cli.py receive
Both sides load the same lock file from ~/psi_bridge/locks/
"""

import sys
import json
import time
import hashlib
import numpy as np
from pathlib import Path
from qpsi_divergence_transport import (
    E8Substrate, DivergenceTransport, EigenmodeEvolution
)

LOCKS_DIR = Path.home() / "psi_bridge" / "locks"
STATE_FILE = Path.home() / "psi_bridge" / "divergence_state.json"


def load_lock() -> dict:
    """Load the most recent lock file."""
    lock_files = list(LOCKS_DIR.glob("*.lock")) + list(LOCKS_DIR.glob("*.json"))
    lock_files = [f for f in lock_files if f.name != "divergence_state.json"]
    if not lock_files:
        print("No lock file found in ~/psi_bridge/locks/")
        sys.exit(1)
    newest = max(lock_files, key=lambda f: f.stat().st_mtime)
    print(f"Lock: {newest.name}")
    with open(newest) as f:
        data = json.load(f)
    # Normalize field names
    for field, alts in {
        'local_vector': ['local_state', 'local_vec'],
        'remote_vector': ['remote_state', 'remote_vec', 'peer_vector'],
        'fingerprint': ['combined_fingerprint', 'lock_fingerprint'],
    }.items():
        if field not in data:
            for alt in alts:
                if alt in data:
                    data[field] = data[alt]
                    break
    if 'lock_time' not in data:
        data['lock_time'] = newest.stat().st_mtime
    return data


def cmd_send(message: str):
    """Encode message as perturbation sequence and save state."""
    print(f"Message: '{message}'")
    print("Initializing E8 substrate...")
    e8 = E8Substrate()
    lock = load_lock()
    transport = DivergenceTransport(e8, lock)
    
    transport.send(message)
    total_bytes = transport.pending_tx()
    print(f"Encoded: {total_bytes} bytes in TX queue")
    
    # Run TX steps — collect the perturbed states
    states = []
    for i in range(total_bytes + 5):
        state = transport._tx_step()
        states.append(state.tolist())
    
    # Save the perturbed state sequence
    output = {
        'message': message,
        'timestamp': time.time(),
        'lock_fingerprint': lock.get('fingerprint', ''),
        'total_steps': len(states),
        'states': states,
        'stats': transport.stats(),
    }
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, 'w') as f:
        json.dump(output, f)
    
    print(f"Transmitted {transport.stats()['bytes_sent']} bytes over {len(states)} steps")
    print(f"State saved to {STATE_FILE}")
    print(f"Transfer this file to the receiver, or test locally.")


def cmd_receive():
    """Load perturbed state sequence and decode via divergence detection."""
    if not STATE_FILE.exists():
        print(f"No state file found at {STATE_FILE}")
        print("Run 'send' first, then copy divergence_state.json to this machine.")
        sys.exit(1)
    
    with open(STATE_FILE) as f:
        data = json.load(f)
    
    print(f"State file: {len(data['states'])} steps, from {data.get('timestamp', '?')}")
    print("Initializing E8 substrate...")
    e8 = E8Substrate()
    lock = load_lock()
    
    # Verify same lock
    if lock.get('fingerprint', '') != data.get('lock_fingerprint', 'x'):
        print("WARNING: Lock fingerprint mismatch — different lock files")
    
    transport = DivergenceTransport(e8, lock)
    
    # Feed the sender's actual states into the receiver
    for i, state_list in enumerate(data['states']):
        observed = np.array(state_list, dtype=np.float64)
        decoded = transport._rx_step(observed)
        if decoded is not None:
            transport._process_rx_byte(decoded)
    
    messages = transport.get_messages()
    stats = transport.stats()
    
    print(f"Bytes received: {stats['bytes_received']}")
    print(f"Decode errors: {stats['decode_errors']}")
    
    if messages:
        for msg in messages:
            print(f"\nRECEIVED: '{msg['text']}'")
            if msg['text'] == data['message']:
                print("VERIFIED: Message matches what sender transmitted.")
            else:
                print(f"MISMATCH: Expected '{data['message']}'")
    else:
        print("\nNo messages decoded.")


def cmd_loopback(message: str):
    """Send and receive in one shot — proves the codec works."""
    print(f"Loopback test: '{message}'")
    e8 = E8Substrate()
    lock = load_lock()
    
    sender = DivergenceTransport(e8, lock)
    # Receiver gets swapped vectors (simulates other machine)
    lock_b = dict(lock)
    lock_b['local_vector'] = lock['remote_vector']
    lock_b['remote_vector'] = lock['local_vector']
    receiver = DivergenceTransport(e8, lock_b)
    
    sender.send(message)
    total = sender.pending_tx()
    
    for i in range(total + 5):
        a_state = sender._tx_step()
        decoded = receiver._rx_step(a_state)
        if decoded is not None:
            receiver._process_rx_byte(decoded)
    
    messages = receiver.get_messages()
    if messages and messages[0]['text'] == message:
        print(f"PASS: '{messages[0]['text']}'")
    else:
        print(f"FAIL: got {messages}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python3 qpsi_cli.py send \"your message\"")
        print("  python3 qpsi_cli.py receive")
        print("  python3 qpsi_cli.py loopback \"test message\"")
        sys.exit(1)
    
    cmd = sys.argv[1]
    if cmd == 'send':
        msg = sys.argv[2] if len(sys.argv) > 2 else f"test_{int(time.time())}"
        cmd_send(msg)
    elif cmd == 'receive':
        cmd_receive()
    elif cmd == 'loopback':
        msg = sys.argv[2] if len(sys.argv) > 2 else f"loopback_{int(time.time())}"
        cmd_loopback(msg)
    else:
        print(f"Unknown command: {cmd}")
