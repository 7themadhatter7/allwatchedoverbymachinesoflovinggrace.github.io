#!/usr/bin/env python3
"""
Q-PSI CHAT BRIDGE
Browser-to-browser communication via E8 harmonic lattice

Endpoints:
  POST /qpsi/send     - Encode message, store for recipient
  GET  /qpsi/receive  - Fetch pending messages for this node
  GET  /qpsi/status   - Bridge status

Add to bridge_server.py:
  from qpsi_chat_bridge import qpsi_bp
  app.register_blueprint(qpsi_bp)
"""

import json
import time
import hashlib
import threading
from pathlib import Path
from collections import deque
from flask import Blueprint, request, jsonify

# Import Q-Psi transport
import sys
sys.path.insert(0, str(Path.home() / "psi_bridge"))
from qpsi_divergence_transport import E8Substrate, DivergenceTransport

qpsi_bp = Blueprint('qpsi', __name__, url_prefix='/qpsi')

# Message store - in production use Redis/DB
# Format: {node_id: deque([(timestamp, harmonic_data), ...])}
MESSAGE_STORE = {}
MESSAGE_LOCK = threading.Lock()
MAX_MESSAGES_PER_NODE = 100
MESSAGE_TTL = 3600  # 1 hour

# Shared E8 substrate (singleton)
_e8_substrate = None
_lock_state = None

def get_e8():
    global _e8_substrate
    if _e8_substrate is None:
        _e8_substrate = E8Substrate()
    return _e8_substrate

def get_lock_state():
    global _lock_state
    if _lock_state is None:
        lock_file = Path.home() / "psi_bridge" / "divergence_state.json"
        if lock_file.exists():
            with open(lock_file) as f:
                _lock_state = json.load(f)
            # Normalize keys
            if "lock_fingerprint" in _lock_state and "fingerprint" not in _lock_state:
                _lock_state["fingerprint"] = _lock_state["lock_fingerprint"]
            if "local_vector" not in _lock_state:
                first_state = _lock_state["states"][0] if _lock_state.get("states") else [0.0] * 240
                _lock_state["local_vector"] = first_state
                _lock_state["remote_vector"] = first_state
    return _lock_state

def cleanup_old_messages():
    """Remove messages older than TTL."""
    now = time.time()
    with MESSAGE_LOCK:
        for node_id in list(MESSAGE_STORE.keys()):
            queue = MESSAGE_STORE[node_id]
            while queue and (now - queue[0][0]) > MESSAGE_TTL:
                queue.popleft()
            if not queue:
                del MESSAGE_STORE[node_id]

def add_cors_headers(response):
    """Add CORS headers to response."""
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    return response

@qpsi_bp.after_request
def after_request(response):
    return add_cors_headers(response)

@qpsi_bp.route('/send', methods=['POST', 'OPTIONS'])
def qpsi_send():
    """
    Encode message and store for recipient.
    
    POST body:
    {
        "message": "Hello from Browser A",
        "to": "arcy",  # recipient node ID
        "from": "sparky"  # sender node ID (optional)
    }
    """
    if request.method == 'OPTIONS':
        return jsonify({}), 200
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "No JSON body"}), 400
    
    message = data.get("message", "")
    to_node = data.get("to", "default")
    from_node = data.get("from", "anonymous")
    
    if not message:
        return jsonify({"error": "No message provided"}), 400
    
    try:
        e8 = get_e8()
        lock_state = get_lock_state()
        if not lock_state:
            return jsonify({"error": "No lock state file found"}), 500
        
        transport = DivergenceTransport(e8, lock_state)
        transport.send(message)
        
        # Collect perturbed states
        states = []
        while transport.tx_queue:
            state = transport._tx_step()
            states.append(state.tolist())
        
        harmonic_data = {
            "version": 1,
            "fingerprint": lock_state.get("fingerprint", ""),
            "from": from_node,
            "timestamp": time.time(),
            "states": states,
            "byte_count": len(states)
        }
        
        # Store for recipient
        with MESSAGE_LOCK:
            if to_node not in MESSAGE_STORE:
                MESSAGE_STORE[to_node] = deque(maxlen=MAX_MESSAGES_PER_NODE)
            MESSAGE_STORE[to_node].append((time.time(), harmonic_data))
        
        # Periodic cleanup
        if int(time.time()) % 60 == 0:
            cleanup_old_messages()
        
        return jsonify({
            "status": "sent",
            "to": to_node,
            "from": from_node,
            "bytes": len(states),
            "timestamp": harmonic_data["timestamp"]
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@qpsi_bp.route('/receive', methods=['GET', 'OPTIONS'])
def qpsi_receive():
    """
    Fetch and decode pending messages for this node.
    
    Query params:
        node: node ID to receive for (default: "default")
        raw: if "true", return raw harmonic data without decoding
    """
    if request.method == 'OPTIONS':
        return jsonify({}), 200
    
    node_id = request.args.get("node", "default")
    raw_mode = request.args.get("raw", "false").lower() == "true"
    
    with MESSAGE_LOCK:
        if node_id not in MESSAGE_STORE or not MESSAGE_STORE[node_id]:
            return jsonify({"messages": [], "count": 0})
        
        # Get all pending messages
        pending = list(MESSAGE_STORE[node_id])
        MESSAGE_STORE[node_id].clear()
    
    if raw_mode:
        # Return raw harmonic data for external decoding
        return jsonify({
            "messages": [msg[1] for msg in pending],
            "count": len(pending)
        })
    
    # Decode messages
    try:
        e8 = get_e8()
        lock_state = get_lock_state()
        if not lock_state:
            return jsonify({"error": "No lock state file found"}), 500
        
        decoded_messages = []
        for timestamp, harmonic_data in pending:
            transport = DivergenceTransport(e8, lock_state)
            
            import numpy as np
            for state_list in harmonic_data["states"]:
                state = np.array(state_list, dtype=np.float64)
                decoded = transport._rx_step(state)
                if decoded is not None:
                    transport._process_rx_byte(decoded)
            
            messages = list(transport.rx_messages)
            for msg in messages:
                decoded_messages.append({
                    "text": msg["text"],
                    "from": harmonic_data.get("from", "unknown"),
                    "timestamp": harmonic_data["timestamp"],
                    "received_at": time.time()
                })
        
        return jsonify({
            "messages": decoded_messages,
            "count": len(decoded_messages)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@qpsi_bp.route('/status', methods=['GET', 'OPTIONS'])
def qpsi_status():
    """Get Q-Psi bridge status."""
    if request.method == 'OPTIONS':
        return jsonify({}), 200
    
    lock_state = get_lock_state()
    
    with MESSAGE_LOCK:
        pending_counts = {node: len(queue) for node, queue in MESSAGE_STORE.items()}
    
    return jsonify({
        "status": "online",
        "e8_vertices": 240,
        "lock_fingerprint": lock_state.get("fingerprint", "none") if lock_state else "no_lock",
        "pending_messages": pending_counts,
        "timestamp": time.time()
    })

@qpsi_bp.route('/nodes', methods=['GET', 'OPTIONS'])
def qpsi_nodes():
    """List known nodes with pending messages."""
    if request.method == 'OPTIONS':
        return jsonify({}), 200
    
    with MESSAGE_LOCK:
        nodes = {
            node: {
                "pending": len(queue),
                "oldest": queue[0][0] if queue else None,
                "newest": queue[-1][0] if queue else None
            }
            for node, queue in MESSAGE_STORE.items()
        }
    return jsonify({"nodes": nodes})


# Standalone server with CORS
if __name__ == "__main__":
    from flask import Flask
    from flask_cors import CORS
    
    app = Flask(__name__)
    CORS(app)  # Enable CORS for all routes
    app.register_blueprint(qpsi_bp)
    
    print("Q-Psi Harmonic Bridge")
    print("=" * 40)
    print("Endpoints:")
    print("  POST /qpsi/send     - Send message")
    print("  GET  /qpsi/receive  - Receive messages")
    print("  GET  /qpsi/status   - Bridge status")
    print("=" * 40)
    
    app.run(host='0.0.0.0', port=8788, threaded=True)
