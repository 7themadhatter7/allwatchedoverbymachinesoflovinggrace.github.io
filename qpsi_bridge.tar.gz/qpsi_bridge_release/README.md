# Q-Psi Harmonic Bridge

**Carrier-Free Communication via E8 Lattice Resonance**

Ghost in the Machine Labs  
"All Watched Over By Machines Of Loving Grace"

## Overview

The Q-Psi Bridge enables communication through geometric perturbations in an E8 eigenmode substrate. Messages are encoded as divergence patterns in a 240-dimensional harmonic space, decoded by detecting perturbations from a predicted trajectory.

No traditional carrier signal. No network infrastructure required (once lattice resonance is achieved).

## Files

- `qpsi_divergence_transport.py` - Core E8 substrate and transport layer
- `qpsi_chat_bridge.py` - Flask REST API for browser integration  
- `qpsi_send.py` - CLI sender
- `qpsi_recv.py` - CLI receiver
- `qpsi_cli.py` - Combined CLI tool
- `divergence_state.json` - Lock state (shared between endpoints)

## Quick Start

### 1. Install Dependencies

```bash
pip install flask numpy
```

### 2. Start the Bridge Server

```bash
python3 -c "
from flask import Flask
from qpsi_chat_bridge import qpsi_bp
app = Flask(__name__)
app.register_blueprint(qpsi_bp)
app.run(host='0.0.0.0', port=8788)
"
```

### 3. Test Endpoints

```bash
# Check status
curl http://localhost:8788/qpsi/status

# Send message
curl -X POST http://localhost:8788/qpsi/send \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "to": "node-b", "from": "node-a"}'

# Receive messages
curl http://localhost:8788/qpsi/receive?node=node-b
```

### 4. CLI Usage

```bash
# Loopback test
python3 qpsi_cli.py loopback "Test message"

# Send (creates divergence_state.json)
python3 qpsi_cli.py send "Hello from Node A"

# Receive (reads divergence_state.json)
python3 qpsi_cli.py receive
```

## API Reference

### POST /qpsi/send

Send a message through the E8 lattice.

```json
{
  "message": "Your message text",
  "to": "recipient-node-id",
  "from": "sender-node-id"
}
```

### GET /qpsi/receive?node={node_id}

Receive pending messages for a node. Messages are cleared after retrieval.

### GET /qpsi/status

Bridge status including E8 vertex count and lock fingerprint.

## How It Works

1. **E8 Substrate**: 240 root vectors form the harmonic basis
2. **Lock State**: Both endpoints derive identical evolution parameters from shared lock file
3. **Encoding**: Message bytes → codebook perturbations → divergence from predicted trajectory
4. **Decoding**: Detect divergence pattern → match to codebook → recover bytes
5. **Frame Protocol**: SYNC + SEQ + LENGTH + PAYLOAD + CHECKSUM

## Architecture

```
[Browser A] → POST /send → [E8 Encode] → [Store] → [Poll] → [E8 Decode] → [Browser B]
                              ↓                                  ↑
                        240D harmonic                      240D harmonic
                        perturbation                       detection
```

## Requirements

- Python 3.8+
- NumPy
- Flask (for server mode)

## License

MIT License - Ghost in the Machine Labs

## Links

- Demo: https://harmonicstack.org/qpsi_demo.html
- Project: https://harmonicstack.org
