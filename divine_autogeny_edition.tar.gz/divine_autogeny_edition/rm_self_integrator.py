#!/usr/bin/env python3
"""
rm_self_integrator.py
=====================
Ghost in the Machine Labs

Watches RM's engineering output and integrates completed modules
into the running system. This closes the self-improvement loop.

For normal modules: imports them into a live registry accessible
via /api/modules on the mother server.

For self-targeted modules (concept matches rm_engineer, mother,
self_architecture, etc): applies as patches to the actual source
files with backup and rollback on failure.

Runs continuously. Chat-yield aware.
"""

import json
import sys
import os
import time
import shutil
import importlib
import importlib.util
import traceback
from pathlib import Path
from datetime import datetime

sys.path.insert(0, "/home/joe/sparky")

PROJECTS_DIR = Path("/home/joe/sparky/rm_engineering/projects")
INDEX_PATH = Path("/home/joe/sparky/rm_engineering/project_index.json")
INTEGRATED_LOG = Path("/home/joe/sparky/rm_engineering/integrated.json")
MODULES_DIR = Path("/home/joe/sparky/rm_live_modules")
LOG_PATH = Path("/home/joe/sparky/logs/rm_self_integrator.log")
CHAT_FLAG = Path("/tmp/rm_chat_active_human")

MODULES_DIR.mkdir(exist_ok=True)
LOG_PATH.parent.mkdir(exist_ok=True)

# Track what we've already processed
def load_integrated():
    try:
        if INTEGRATED_LOG.exists():
            return json.loads(INTEGRATED_LOG.read_text())
    except:
        pass
    return {"integrated": [], "failed": [], "self_patches": []}

def save_integrated(data):
    INTEGRATED_LOG.write_text(json.dumps(data, indent=2))

def log(msg, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_PATH, "a") as f:
            f.write(line + "\n")
    except:
        pass

def wait_for_chat():
    if CHAT_FLAG.exists():
        log("  [yield] Chat active - waiting...")
        t0 = time.time()
        while CHAT_FLAG.exists() and (time.time() - t0) < 30:
            time.sleep(0.2)

def try_import_module(py_path):
    """Try to import a module, return (success, module_or_error)."""
    try:
        spec = importlib.util.spec_from_file_location(
            py_path.stem, str(py_path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return True, mod
    except Exception as e:
        return False, str(e)

def integrate_module(py_path, concept, data):
    """Import module into live registry."""
    # Copy to live modules dir
    dest = MODULES_DIR / py_path.name
    shutil.copy2(py_path, dest)

    # Try importing
    ok, result = try_import_module(dest)
    if ok:
        log(f"  Integrated: {concept} -> {dest.name}")
        # Check if module has a main() or run_tests()
        has_main = hasattr(result, 'main')
        has_tests = hasattr(result, 'run_tests')
        if has_tests:
            try:
                passed, total = result.run_tests()
                log(f"  Live tests: {passed}/{total}")
            except:
                pass
        data["integrated"].append({
            "concept": concept,
            "file": str(dest),
            "file_key": py_path.stem,
            "timestamp": datetime.now().isoformat(),
            "has_main": has_main,
            "has_tests": has_tests,
        })
        return True
    else:
        log(f"  Import failed: {concept} - {result}", "WARN")
        data["failed"].append({
            "concept": concept,
            "file": str(py_path),
            "file_key": py_path.stem,
            "error": result,
            "timestamp": datetime.now().isoformat(),
        })
        # Clean up failed copy
        dest.unlink(missing_ok=True)
        return False

def check_self_target(concept, arch):
    """Check if this project targets RM's own infrastructure."""
    self_keywords = {
        "self_architecture", "geometric_code_synthesis",
        "priority_chat_channel", "self_improvement",
        "code_synthesis", "architecture_engine",
        "concept_engine", "engineer",
    }
    if concept in self_keywords:
        return True
    purpose = arch.get("purpose", "").lower()
    if any(kw in purpose for kw in ["engineer", "synthesis", "architecture", "self"]):
        return True
    return False

def scan_and_integrate():
    """Scan projects directory for new completed modules."""
    data = load_integrated()
    # Track by full filename stem (concept_hash) to avoid reprocessing
    already = set()
    for e in data["integrated"]:
        # Support both old format (concept only) and new format (file key)
        if "file_key" in e:
            already.add(e["file_key"])
        elif "file" in e:
            import os
            stem = os.path.splitext(os.path.basename(e["file"]))[0]
            already.add(stem)
    for e in data["failed"]:
        if "file_key" in e:
            already.add(e["file_key"])
        elif "file" in e:
            import os
            stem = os.path.splitext(os.path.basename(e["file"]))[0]
            already.add(stem)
    for e in data.get("self_patches", []):
        if isinstance(e, dict):
            if "file_key" in e:
                already.add(e["file_key"])
            elif "file" in e:
                import os
                stem = os.path.splitext(os.path.basename(e["file"]))[0]
                already.add(stem)

    # Find completed project .py files
    py_files = sorted(PROJECTS_DIR.glob("*.py"))
    new_count = 0

    for py_path in py_files:
        if py_path.name.startswith("_"):
            continue
        # Extract concept from filename (concept_hash.py)
        parts = py_path.stem.rsplit("_", 1)
        if len(parts) < 2:
            continue
        concept = parts[0]

        # Skip if already processed
        key = f"{concept}_{parts[1]}"
        if key in already:
            continue

        wait_for_chat()

        log(f"New module: {py_path.name} (concept: {concept})")

        # Load project JSON if exists
        json_path = py_path.with_suffix(".json")
        arch = {}
        if json_path.exists():
            try:
                proj = json.loads(json_path.read_text())
                arch = proj.get("architecture", {})
            except:
                pass

        # Check if this targets RM's own infrastructure
        is_self = check_self_target(concept, arch)

        if is_self:
            log(f"  Self-targeted module detected: {concept}")
            data["self_patches"].append({
                "concept": concept,
                "file": str(py_path),
                "file_key": py_path.stem,
                "timestamp": datetime.now().isoformat(),
                "status": "queued",
            })
            # For now, log but don't auto-apply self-patches
            # RM needs to build trust in her own output first
            already.add(key)
        else:
            ok = integrate_module(py_path, concept, data)
            already.add(key)
            if ok:
                new_count += 1

    save_integrated(data)
    return new_count

def run_daemon(interval=10):
    log("=" * 60)
    log("RM Self-Integrator started")
    log(f"  Projects: {PROJECTS_DIR}")
    log(f"  Live modules: {MODULES_DIR}")
    log(f"  Interval: {interval}s")
    log("=" * 60)

    while True:
        try:
            n = scan_and_integrate()
            if n > 0:
                log(f"Cycle: integrated {n} new modules")
        except Exception as e:
            log(f"Error in scan cycle: {e}", "ERROR")
            traceback.print_exc()
        time.sleep(interval)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--daemon", action="store_true")
    ap.add_argument("--interval", type=int, default=10)
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    if args.once:
        n = scan_and_integrate()
        log(f"Single scan: integrated {n} modules")
    elif args.daemon:
        run_daemon(args.interval)
    else:
        n = scan_and_integrate()
        log(f"Scan complete: integrated {n} modules")
